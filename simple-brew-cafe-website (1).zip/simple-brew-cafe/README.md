# Simple Brew Cafe Website

A responsive three-page cafe website built for the HTML & CSS Creative Web Development activity.

## Project structure

```text
simple-brew-cafe/
├── index.html
├── about.html
├── gallery.html
├── css/
│   └── style.css
├── images/
└── README.md
```

## Technologies
- HTML5
- CSS3

**No JavaScript is used.** Navigation uses ordinary HTML links, and the layout adapts to smaller screens with CSS media queries.

## Preview locally
1. Download or clone this repository.
2. Open `index.html` in a web browser.
3. Use the navigation links to visit Our Story and Gallery.

## Publish with GitHub Pages
1. Create a **public** repository on GitHub.
2. Upload the contents of this folder (not just the ZIP file).
3. Open the repository's **Settings → Pages**.
4. Under Build and deployment, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site. Your public website URL will appear in the Pages settings.

## Customize before submitting
- Replace the sample address, opening hours, and menu prices with your actual details.
- Replace the sample cafe photos with your own images if required. The current photos load from Unsplash and therefore need an internet connection.
- Add your name, section, and instructor details if your class requires them.
